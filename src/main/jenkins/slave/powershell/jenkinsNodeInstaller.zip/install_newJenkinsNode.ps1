param(
	
	[parameter(Mandatory=$true)]
    [String]
    $nodeName,
    
	[parameter(Mandatory=$true)]
	[String]
	$jnlpUrl,
	
	[parameter(Mandatory=$true)]
	[String]
	$secret,
	
	[parameter(Mandatory=$true)]
	[String]
	$workDir,
	
	[parameter(Mandatory=$true)]
	[String]
	$slavesHomeFolder,
	
	[parameter(Mandatory=$true)]
	[String]
	$initAndCleanHomeFolder
)

New-Item -ItemType directory -Path "${slavesHomeFolder}\${nodeName}"
Expand-Archive "winAgent.zip" "${slavesHomeFolder}\${nodeName}"
Rename-Item "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent.exe" "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.exe"
Rename-Item "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent.xml" "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.xml"
Rename-Item "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent.exe.config" "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.exe.config"

(Get-Content "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.xml").replace('[env]', "${nodeName}") | Set-Content "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.xml"
(Get-Content "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.xml").replace('[jnlpUrl]', "${jnlpUrl}") | Set-Content "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.xml"
(Get-Content "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.xml").replace('[secret]', "${secret}") | Set-Content "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.xml"
(Get-Content "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.xml").replace('[workdir]', "${workDir}") | Set-Content "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.xml"

if (-Not(Test-Path "${initAndCleanHomeFolder}")) {
	New-Item -ItemType directory -Path "${initAndCleanHomeFolder}"
}
Expand-Archive "initAndCleanScripts.zip" "${initAndCleanHomeFolder}"
Rename-Item "${initAndCleanHomeFolder}\clean_install_it21gui.ps1" "${initAndCleanHomeFolder}\clean_install_${nodeName}_it21gui.ps1"
Rename-Item "${initAndCleanHomeFolder}\init_install_it21gui.ps1" "${initAndCleanHomeFolder}\init_install_${nodeName}_it21gui.ps1" 

(Get-Content "${initAndCleanHomeFolder}\init_install_${nodeName}_it21gui.ps1").replace('[env]', "${nodeName}") | Set-Content "${initAndCleanHomeFolder}\init_install_${nodeName}_it21gui.ps1"
(Get-Content "${initAndCleanHomeFolder}\clean_install_${nodeName}_it21gui.ps1").replace('[env]', "${nodeName}") | Set-Content "${initAndCleanHomeFolder}\clean_install_${nodeName}_it21gui.ps1"

$serviceInstaller = "${slavesHomeFolder}\${nodeName}\JenkinsWinAgent${nodeName}.exe"
& $serviceInstaller "uninstall"
& $serviceInstaller "install"