param(
	
	[parameter(Mandatory=$true)]
    [String]
    $serviceIdentifier,
    
	[parameter(Mandatory=$true)]
	[String]
	$jnlpUrl,
	
	[parameter(Mandatory=$true)]
	[String]
	$secret,
	
	[parameter(Mandatory=$true)]
	[String]
	$workDir,
	
	[parameter(Mandatory=$true)]
	[String]
	$slavesHomeFolder
	
	#[parameter(Mandatory=$true)]
	#[String]
	#$initAndCleanHomeFolder
)

New-Item -ItemType directory -Path "${slavesHomeFolder}\${serviceIdentifier}"

$myPath = Split-Path -Path ${MyInvocation}.MyCommand.Path
Push-Location -Path "${myPath}"
Expand-Archive "winAgent.zip" "${slavesHomeFolder}\${serviceIdentifier}"

Rename-Item "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent.exe" "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.exe"
Rename-Item "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent.xml" "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.xml"
Rename-Item "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent.exe.config" "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.exe.config"

(Get-Content "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.xml").replace('[env]', "${serviceIdentifier}") | Set-Content "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.xml"
(Get-Content "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.xml").replace('[jnlpUrl]', "${jnlpUrl}") | Set-Content "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.xml"
(Get-Content "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.xml").replace('[secret]', "${secret}") | Set-Content "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.xml"
(Get-Content "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.xml").replace('[workdir]', "${workDir}") | Set-Content "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.xml"

#if (-Not(Test-Path "${initAndCleanHomeFolder}")) {
#	New-Item -ItemType directory -Path "${initAndCleanHomeFolder}"
#}
#Expand-Archive "initAndCleanScripts.zip" "${initAndCleanHomeFolder}"
#Rename-Item "${initAndCleanHomeFolder}\clean_install_it21gui.ps1" "${initAndCleanHomeFolder}\clean_install_${serviceIdentifier}_it21gui.ps1"
#Rename-Item "${initAndCleanHomeFolder}\init_install_it21gui.ps1" "${initAndCleanHomeFolder}\init_install_${serviceIdentifier}_it21gui.ps1" 

#(Get-Content "${initAndCleanHomeFolder}\init_install_${serviceIdentifier}_it21gui.ps1").replace('[env]', "${serviceIdentifier}") | Set-Content "${initAndCleanHomeFolder}\init_install_${serviceIdentifier}_it21gui.ps1"
#(Get-Content "${initAndCleanHomeFolder}\clean_install_${serviceIdentifier}_it21gui.ps1").replace('[env]', "${serviceIdentifier}") | Set-Content "${initAndCleanHomeFolder}\clean_install_${serviceIdentifier}_it21gui.ps1"

$serviceInstaller = "${slavesHomeFolder}\${serviceIdentifier}\JenkinsWinAgent${serviceIdentifier}.exe"
& $serviceInstaller "uninstall"
& $serviceInstaller "install"